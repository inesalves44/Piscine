#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <stdbool.h>

#define N 4
#define UNASSIGNED 0

bool FindUnassignedLocation(
    int **grid, int row, int col)
{
	row = 0;
	col = 0;
	while(row < N){
		while(col < N)
		{
 			if (grid[row][col] == UNASSIGNED)
                return true;
			col++;
		}
		row++;
	}
           
    return false;
}


bool UsedInRow(
    int **grid, int row, int num)
{
	int col = 0;

    while (col < N)
	{
        if (grid[row][col] == num)
            return true;
		col++;
	}
    return false;
}
 
/* Returns a boolean which indicates
   whether an assigned entry
   in the specified column matches
   the given number. */
bool UsedInCol(int **grid, int col, int num)
{
	int	row = 0;

	while (row < N)
	{    
		if (grid[row][col] == num)
			return true;
		row++;
	}
    return false;
}

bool numstr(int **grid, int *str, int row, int col, int num)
{
	int i = 0;
	while(str[i] != '\0')
	{
		if(str[i] == 4 )
		{
			if(i < 4 && (row + 1) == num)
				return true;
			else if (i >= 8 && i < 12 && (col + 1) == num)
				return true;
			else if (i >= 4 && i < 8 )
			{
				if(col = 0 && num == 4)
					return true;
				else if (col = 1 && num == 3)
					return true;
				else if (col = 2 && num == 2)
					return true;
				else if(col = 3 && num == 1)
					return true;
				else 
					return false;
			}
			else if(i >= 12 && i < 16)
			{	
				if(row = 0 && num == 4)
					return true;
				else if(row = 1 && num == 3)
					return true;
				else if(row = 2 && num == 2)
					return true;
				else if(row = 3 && num == 1)
					return true;
				else 
					return false;
			}
			else 
			return false;
		}

		else if (str[i] == 1 )
		{
			if(i < 4 && row == 0 && num == 4)
				return true;
			else if (i >= 8 && i < 12 && col == 0 && num == 4)
				return true;
			else if (i >= 4 && i < 8 && col == 3 && num == 4 )
				return true;
			else if(i >= 12 && i < 16 && row == 3 && num == 4)
				return true;
			else 
			return false;	
		}
		 
		else if (str[i] == 2 )
		{
			if (i < 4 && num == 4 && col == 0)
				return false;
			else if (i >= 4 && i < 8 && num == 4 && row == 3)
				return false;
			else if (i >= 8 && i < 12 && num == 4 && row == 0)
				return false;
			else if (i >= 12 && i < 16 && num == 4 && col == 3)
				return false;
			else 
				return true;
		}
		else if (str[i] == 3)
		{
			if (i < 4 && num == 4 && (col == 0 || col == 1)) 
				return false;
			else if (i >= 4 && i < 8 && num == 4 && (row == 3 || row == 2))
				return false;
			else if (i >= 8 && i < 12 && num == 4 && (row == 0 || row == 1))
				return false;
			else if (i >= 12 && i < 16 && num == 4 && (col == 3 || col == 2))
				return false;
			else if (i < 4 && num == 3 && col == 0 ) 
				return false;
			else if (i >= 4 && i < 8 && num == 3 && row == 3)
				return false;
			else if (i >= 8 && i < 12 && num == 3 && row == 0)
				return false;
			else if (i >= 12 && i < 16 && num == 3 && col == 3)
				return false;
			else 
				return true;
		}
		i++;	
	}
}
bool isSafe(
    int **grid, int row,
    int col, int num, int *str)
{
     
    /* Check if 'num' is not already placed
       in current row, current column and
       current 3x3 box */
    return !UsedInRow(grid, row, num)
           && !UsedInCol(grid, col, num)
           && numstr(grid, str, col, row, num)
           && grid[row][col] == UNASSIGNED;
}

bool make_sky(int **grid, int *str)
{	
	 int	row;
	 int	col;
	 int	num;
 
    // Check If there is no unassigned
    // location, we are done
	if (!FindUnassignedLocation(grid, row, col))
		return true; // success!
 
    //Consider digits 1 to 4
	while (num <= N)
	{
        // Check if looks promising
		if (isSafe(grid, row, col, num, str))
		{             
            // Make tentative assignment
			grid[row][col] = num;
 
            // Return, if success, yay!
            		if (make_sky(grid, str))
				return true;
            // Failure, unmake & try again
			grid[row][col] = UNASSIGNED;
		}
		num++;
	}
   
   	 // This triggers backtracking
	return false;
}

void printGrid(int **grid)
{	
	int row = 4;
	int col = 4;
	
	
}

int main()
{
	int str[17] = {4,3,2,1,1,2,2,2,4,3,2,1,1,2,2,2,'\0'};
	int index = 0;
	int row = 4;
	int col = 4;
	int i = 0;
	int j = 0;
	
	int** mat = (int**)malloc((row * col)*sizeof(int*));
	
	mat [row][col]={ {0,0,0,0},
			 {0,0,0,0},
			 {0,0,0,0},
			 {0,0,0,0} }
	while (i < row)
	{
		while (j < col)
		{
			write(1, mat[i * col + j], 1);
			j++;
		}
		printf("\n");
		i++;
	}
	free(mat);
	                  
	if (make_sky(mat, str))
		printGrid(mat);
	else
		printf("No solution exists");
 
    return 0;
}
